﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EduWeb.Controllers
{
    public class BlogController : Controller
    {
        // GET: Blog
        public ActionResult Blog()
        {
            return View();
        }
        public ActionResult EDKerexcitedly()
        {
            return View();
        }
        public ActionResult EDKerisready()
        {
            return View();
        }
        public ActionResult EDKstudents()
        {
            return View();
        }
        public ActionResult ITtrainingmodel()
        {
            return View();
        }
        public ActionResult Learningtocode()
        {
            return View();
        }
    }
}